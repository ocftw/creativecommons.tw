
What is this?
=============
This is a tool to easily and quickly set up your own mediagoblin instance,
either to run a server, or to help develop mediagoblin yourself.

How to set up a mediagoblin instance
====================================
There are two scripts inside this directory:
    'run_easy_install' and 'run_archive_easy_install'. 
They simply install different flavors of mediagoblin. See the section below to
decide which will work better for your instance. Once you have chosen which
script you would like to use, run it.

It will ask you a series of questions about your website and then install your
server into the directory that you specify. The script must be run by a user
with root privileges. This script should take 5-15 minutes, but will not prompt
the user for questions after the first questions are over. When that script is
over, your server will be functional, although empty.
______________________________________________________________________________
NOTE: If you installed your mediagoblin server with nginx, then you will need to
restart nginx or restart your computer before the server will work correctly.
To restart nginx type these commands into the server's terminal:
    $ sudo /etc/init.d/nginx restart
    $ sudo /etc/rc.d/nginx restart
``````````````````````````````````````````````````````````````````````````````

To run your server locally use the command
    $ sudo -u mediagoblin ./lazyserver.sh
If you installed your server with nginx, you can run the command
    $ sudo -u mediagoblin ./run_nginx_server.sh
To hook your server into your nginx app

Once you've done this, the initial sever set up should be finished!
Congratulations! You'll probably want to create a user now and start uploading
media, but any further decisions are beyond the scope of this script.
Consult these websites for more information:
    http://docs.mediagoblin.org
    http://wiki.mediagoblin.org
and feel free to ask questions at our irc.freenode.org channel at
    #mediagoblin

What is run_archive_easy_install?
=================================
This script installs mediagoblin with a group of different settings and plugins
enabled than the default. The differences are:
    o These instances of mediagoblin will have a homepage centered on featured
      media, rather than a gallery of 'most recent media'
    o When users register in an archival mediagoblin instance, by default they
      cannot upload media.
    o Archival instances display media entry metadata in the media sidebar.

How can I create a custom install?
==================================
Check out README.txt in the mediagoblin_easy_install/plugins/ directory, and try
to examine some of the code as well.
